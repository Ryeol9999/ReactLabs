import React from "react";
import BoardList from "./components/BoardList";

function App() {
  return (
    <div>
      <BoardList />
    </div>
  );
}

export default App;
